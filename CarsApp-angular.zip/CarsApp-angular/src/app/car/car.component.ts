import { Component, OnInit } from '@angular/core';
import { Response } from '@angular/http';
import { CarService } from '../services/car.services';
import Car from '../models/car.model';

@Component({
  selector: 'app-car',
  templateUrl: './car.component.html',
  styleUrls: ['./car.component.scss']
})
export class CarComponent implements OnInit {

  constructor(
    //Private carservice will be injected into the component by Angular Dependency Injector
    private carService: CarService
  ) { }

  //Declaring the new car Object and initilizing it
  public newCar: Car = new Car()

  //An Empty list for the visible car list
  carsList: Car[];
  editCars: Car[] = [];


  ngOnInit(): void {

    //At component initialization the 
    this.carService.getCars()
      .subscribe(cars => {
        //assign the carlist property to the proper http response
        this.carsList = cars
        console.log(cars)
      })
  }

  create() {
    this.carService.createCar(this.newCar)
      .subscribe((res) => {
        this.carsList.push(res.data)
        this.newCar = new Car()
        
      })
  }//closes create function

  editCar(car: Car) {
    console.log(car)
     if(this.carsList.includes(car)){
      if(!this.editCars.includes(car)){
        this.editCars.push(car)
      }else{
        this.editCars.splice(this.editCars.indexOf(car), 1)
        this.carService.editCar(car).subscribe(res => {
          console.log('Update Succesful')
         }, err => {
            //this.editCar(car)
            console.error('Update Unsuccesful')
          })
        }
      }
    }

    doneCar(car:Car){
      car.status = 'Sold'
      this.carService.editCar(car).subscribe(res => {
        console.log('Update Succesful')
      }, err => {
        //this.editCar(car)
        console.error('Update Unsuccesful')
      })
    }

    submitCar(event, car:Car){
      if(event.keyCode ==13){
        this.editCar(car)
      }
    }

    deleteCar(car: Car) {
      this.carService.deleteCar(car._id).subscribe(res => {
        this.carsList.splice(this.carsList.indexOf(car), 1);
      })
    }

}
