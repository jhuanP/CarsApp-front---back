import { Response } from '@angular/http';
import { CarService } from './services/car.services';
import Car from './models/car.model';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  ngOnInit(){
    
  }
}
