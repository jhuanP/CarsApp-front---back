import Car from '../models/car.model';
import { Observable } from 'rxjs';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import {Response} from '@angular/http';
import { Injectable } from '@angular/core';

import { map } from 'rxjs/operators';

@Injectable()
export class CarService {

  api_url = 'http://localhost:3000';
  carUrl = `${this.api_url}/api/cars`;

  constructor(
    private http: HttpClient
  ) { }

  // .....some code 

//Create car, takes a Car Object

createCar(car: Car): Observable<any>{
    //returns the observable of http post request 
    return this.http.post(`${this.carUrl}`, car);
  }

//...more code will go down here 

//......some code 

//Read car, takes no arguments
getCars(): Observable<Car[]>{
    return this.http.get(this.carUrl)
    .pipe(map(res  => {
      //Maps the response object sent from the server
        
      return res["data"].docs as Car[];
    }))
  }

  //Update car, takes a Car Object as parameter
    editCar(car:Car){
      let editUrl = `${this.carUrl}`
      //returns the observable of http put request 
      return this.http.put(editUrl, car);
    }
  
  //...some other code 
deleteCar(id:string):any{
    //Delete the object by the id
    let deleteUrl = `${this.carUrl}/${id}`
    return this.http.delete(deleteUrl)
    .pipe(map(res  => {
      return res;
    }))
  }

  private handleError(error: any): Promise<any> {
    console.error('An error occurred', error); 
    // for demo purposes only
    return Promise.reject(error.message || error);
  }


}
