class Car {
    _id:string;
    model: string;
    description: string;
    status: string;
    price: string;
    constructor(){
        this.model = ""
        this.description = ""
        this.status = ""
        this.price = ""
    }
}

export default Car;